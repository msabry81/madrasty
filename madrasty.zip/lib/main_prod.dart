// نقطة دخول الإنتاج: flutter build web --release -t lib/main_prod.dart
import 'bootstrap.dart';
import 'core/app_config.dart';
import 'firebase_options_prod.dart' as opts;

Future<void> main() =>
    bootstrap(Env.prod, opts.DefaultFirebaseOptions.currentPlatform);
